// Exports the "anchor" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/anchor')
//   ES2015:
//     import 'tinymce/plugins/anchor'
require('./plugin.js');