export function index() {
  return http({
    url: 'test',
    method: 'post'
  })
}
