export default {
    welcome: '欢迎'
}