package controller

import (
	"api/api"
	apiLogin "api/api/demo/login"
	"api/internal/service"
	"context"
)

type DemoAdmin struct{}

func NewDemoAdmin() *DemoAdmin {
	return &DemoAdmin{}
}

// 获取加密盐
func (controllerThis *DemoAdmin) Salt(ctx context.Context, req *apiLogin.DemoAdminSaltReq) (res *api.CommonSaltRes, err error) {
	saltStatic, saltDynamic, err := service.DemoAdmin().Salt(ctx, req.Account)
	if err != nil {
		return
	}
	res = &api.CommonSaltRes{SaltStatic: saltStatic, SaltDynamic: saltDynamic}
	return
}

// 登录
func (controllerThis *DemoAdmin) Login(ctx context.Context, req *apiLogin.DemoAdminLoginReq) (res *api.CommonTokenRes, err error) {
	token, err := service.DemoAdmin().Login(ctx, req.Account, req.Password)
	if err != nil {
		return
	}
	res = &api.CommonTokenRes{Token: token}
	return
}
