export default {
    oops: '哎呀！',
    title: '网页跟小鸡鸡一起不见了...',
    tip: '请检查您输入的网址是否正确，或点击下面按钮返回主页。',
    backHome: '返回主页',
}