// 当配置文件用（不用翻译。方便在HTML代码中使用，HTML不支持直接用import.meta.env.XXXX）
export default {
    webTitle: 'XXXX后台',
    VITE_HTTP_API_PREFIX: import.meta.env.VITE_HTTP_API_PREFIX
}