export default {
    name: {
        account: '账号',
        phone: '手机号',
        password: '密码',
    }
}