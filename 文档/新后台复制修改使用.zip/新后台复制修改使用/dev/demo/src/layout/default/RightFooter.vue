<template>
    <ElSpace style="height: 100%; color:#909399; font-size: 14px;">
        Copyright
        <AutoiconEpLocation /> 2022 JB Admin
    </ElSpace>
</template>